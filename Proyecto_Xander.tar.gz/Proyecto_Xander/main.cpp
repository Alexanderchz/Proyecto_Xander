
#include<SDL2/SDL.h>
#include<SDL2/SDL_image.h>
#include<iostream>
#include<vector>
#include<fstream>

using namespace std;

SDL_Window* window;
SDL_Renderer* renderer;
SDL_Event Event;
SDL_Texture *background,*background2,*character,*logo,*logo2;
SDL_Rect rect_background,rect_background2,rect_background3,rect_background4,rect_character,rect_logo,rect_logo2,my_rect;


int screen_width = 500;
int screen_height = 250;

vector<SDL_Texture*> bee_textures;

SDL_Rect bee_rect;

int current_bee_texture = 0;


vector<SDL_Texture*> bee2_textures;

SDL_Rect bee2_rect;

int current_bee2_texture = 0;

bool estaColisionando(SDL_Rect a, SDL_Rect b)
{
    a= rect_character;
    b= bee_rect;

    if(a.x + a.w < b.x)
        return false;

    if(b.x + b.w < a.x)
        return false;

    if(b.y + b.h < a.y)
        return false;

    if(a.y + a.h < b.y)
        return false;

    return true;
}

bool estaColisionando2(SDL_Rect a, SDL_Rect b)
{
    a= rect_character;
    b= bee2_rect;

    if(a.x + a.w < b.x)
        return false;

    if(b.x + b.w < a.x)
        return false;

    if(b.y + b.h < a.y)
        return false;

    if(a.y + a.h < b.y)
        return false;

    return true;
}




int main( int argc, char* args[] )
{
    //Init SDL
    if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
    {
        return 10;
    }
    //Creates a SDL Window
    if((window = SDL_CreateWindow("Image Loading", 100, 100, 1322/*WIDTH*/, 700/*HEIGHT*/, SDL_WINDOW_RESIZABLE | SDL_RENDERER_PRESENTVSYNC)) == NULL)
    {
        return 20;
    }
    //SDL Renderer
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED );
    if (renderer == NULL)
    {
        std::cout << SDL_GetError() << std::endl;
        return 30;
    }

    //Init textures
    int w=0,h=0;
    background = IMG_LoadTexture(renderer,"fondox.jpg");
    SDL_QueryTexture(background, NULL, NULL, &w, &h);
    rect_background.x = 0; rect_background.y = 0; rect_background.w = 1522; rect_background.h = 800;



    logo = IMG_LoadTexture(renderer, "db.png");
    SDL_QueryTexture(character, NULL, NULL, &w, &h);
    rect_logo.x =55; rect_logo.y = 50; rect_logo.w = 250; rect_logo.h = 200;

    logo2 = IMG_LoadTexture(renderer, "Shenron.png");
    SDL_QueryTexture(character, NULL, NULL, &w, &h);
    rect_logo2.x =550; rect_logo2.y = 550; rect_logo2.w = 250; rect_logo2.h = 200;

     character = IMG_LoadTexture(renderer, "goku.png");
    SDL_QueryTexture(character, NULL, NULL, &w, &h);
    rect_character.x =250; rect_character.y = 250; rect_character.w = 70; rect_character.h = 50;



   bee_textures.push_back(IMG_LoadTexture(renderer, "c12.png"));

    bee_textures.push_back(IMG_LoadTexture(renderer, "c21.png"));

    bee_rect.x = 400;

    bee_rect.y = 100;

    bee_rect.w = 80;

    bee_rect.h = 50;

    SDL_QueryTexture(bee_textures[0], NULL, NULL, &bee_rect.w, &bee_rect.h);

    bee2_textures.push_back(IMG_LoadTexture(renderer, "c12.png"));

    bee2_textures.push_back(IMG_LoadTexture(renderer, "c21.png"));

    bee2_rect.x = 900;

    bee2_rect.y = 0;

    SDL_QueryTexture(bee2_textures[0], NULL, NULL, &bee2_rect.w, &bee2_rect.h);


    int frames=0;



    //Main Loop


     bool game_over=false;
    char bee_orientation = 'r';
    char bee2_orientation ='m';
    int velocidad=2;


    while(true)
    {
        while(SDL_PollEvent(&Event))

        {

            if(Event.type == SDL_QUIT)
            {
                return 0;
            }
            if(Event.type == SDL_KEYDOWN)
            {
                if(Event.key.keysym.sym == SDLK_d)
                    rect_character.x+=11
                    ;
            }
            if(Event.type == SDL_QUIT)
                {
                  return 0;
                }
            if(Event.type == SDL_KEYDOWN)
                {
                  if(Event.key.keysym.sym == SDLK_a)
                      rect_character.x-=3;
                }
             if(Event.type == SDL_QUIT)
                {
                  return 0;
                }
            if(Event.type == SDL_KEYDOWN)
                {
                  if(Event.key.keysym.sym == SDLK_w)
                      rect_character.y-=3;
                }
              if(Event.type == SDL_QUIT)
                {
                  return 0;
                }
            if(Event.type == SDL_KEYDOWN)
                {
                  if(Event.key.keysym.sym == SDLK_s)
                      rect_character.y+=3;
                }


            if(Event.type == SDL_QUIT)
            {
                return 0;
            }
            if(Event.type == SDL_KEYDOWN)
            {
                if(Event.key.keysym.sym == SDLK_d)
                    rect_background.x-=velocidad-1;
                if(Event.key.keysym.sym == SDLK_d)
                    rect_background2.x-=velocidad-1;
                if(Event.key.keysym.sym == SDLK_a)
                    rect_background.x+=velocidad-1;
                if(Event.key.keysym.sym == SDLK_a)
                    rect_background2.x+=velocidad-1;

            }
        }

       //Moviemento de abeja 1

        if(bee_rect.y>600)

            bee_orientation='l';



        if(bee_rect.y<0)

            bee_orientation='r';



        if(bee_orientation == 'r')

            bee_rect.y+=2;

        if(bee_orientation == 'l')

            bee_rect.y-=2;

//movimiento abeja 2
 if(bee2_rect.y>600)

            bee2_orientation='l';



        if(bee2_rect.y<0)

            bee2_orientation='m';



        if(bee2_orientation == 'm')

            bee2_rect.y+=2;

        if(bee2_orientation == 'l')

            bee2_rect.y-=2;


        //Animar cuadro x cuadro abeja1

       //Moviemento de abeja


            if(estaColisionando(rect_character,my_rect))
        {
             background2 = IMG_LoadTexture(renderer,"looser.png");
    SDL_QueryTexture(background, NULL, NULL, &w, &h);
    rect_background2.x = 0; rect_background2.y = 0; rect_background2.w = 1200; rect_background2.h = 600;
        }


              if(estaColisionando2(rect_character,my_rect))
        {
            background2 = IMG_LoadTexture(renderer,"looser.png");
    SDL_QueryTexture(background, NULL, NULL, &w, &h);
    rect_background2.x = 0; rect_background2.y = 0; rect_background2.w = 1200; rect_background2.h = 600;





        }

     if(frames%10==0)
        {
            current_bee_texture++;
            if(current_bee_texture >= bee_textures.size())
            {
                current_bee_texture = 0;
            }
        }


          if(rect_character.x>1322)
          {
              ofstream archivo("archivo.txt");
              archivo<<"gano"<<endl;
              archivo.close();

          background2 = IMG_LoadTexture(renderer,"win.png");
    SDL_QueryTexture(background, NULL, NULL, &w, &h);
    rect_background2.x = 0; rect_background2.y = 0; rect_background2.w = 1200; rect_background2.h = 600;



          }



           //animacion cuadro x cuadro abeja 2

           if(frames%10==0)

        {

            current_bee2_texture++;

            if(current_bee2_texture >= bee2_textures.size())

            {

                current_bee2_texture = 0;

            }


            ifstream archivo("archivo.txt");


            cout<<archivo<<endl;
        }
            frames++;




        SDL_RenderCopy(renderer, background, NULL, &rect_background);
        SDL_RenderCopy(renderer, background2, NULL, &rect_background2);
        SDL_RenderCopy(renderer, character, NULL, &rect_character);
        SDL_RenderCopy(renderer, bee_textures[current_bee_texture], NULL, &bee_rect);
        SDL_RenderCopy(renderer, bee2_textures[current_bee2_texture], NULL, &bee2_rect);
        SDL_RenderCopy(renderer, logo, NULL, &rect_logo);
        SDL_RenderCopy(renderer, logo2, NULL, &rect_logo2);
        SDL_RenderPresent(renderer);
        SDL_Delay(1);
    }

	return 0;
}
